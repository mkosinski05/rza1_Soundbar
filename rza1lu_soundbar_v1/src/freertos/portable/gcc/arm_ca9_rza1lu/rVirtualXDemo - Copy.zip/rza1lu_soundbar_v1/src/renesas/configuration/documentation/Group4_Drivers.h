﻿/* Character Encoding: "WHITE SQUARE" U+25A1 is □. */
/*!
@ingroup RENESAS_APPLICATION_SOFTWARE_PACKAGE Software Package
@defgroup  R_SW_PKG_93_NONOS_DRIVERS Drivers (Not POSIX)
@brief     Drivers
*/
