
// TODO: add performance timer stuff here

#define PERF_START
#define PERF_STOP(x)